const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Trip name is required'],
      trim: true,
      minlength: 2
    },
    image: {
      type: String,
      required: [true, 'Trip image is required'],
      trim: true
    },
    description: {
      type: String,
      required: [true, 'Trip description is required'],
      trim: true,
      minlength: 10
    }
  },
  { collection: 'trips', timestamps: true }
);

module.exports = mongoose.model('Trip', tripSchema);
