const travel = async (req, res) => {
  try {
    const response = await fetch(`${req.protocol}://${req.get('host')}/api/trips`);

    if (!response.ok) {
      return res.status(response.status).render('error', {
        title: 'Travlr Getaways',
        message: 'Unable to retrieve travel information.'
      });
    }

    const trips = await response.json();

    return res.render('travel', {
      title: 'Travlr Getaways',
      trips
    });
  } catch (err) {
    console.error('Unable to retrieve trips from API:', err.message);
    return res.status(500).render('error', {
      title: 'Travlr Getaways',
      message: 'Unable to retrieve travel information.'
    });
  }
};

module.exports = {
  travel
};
