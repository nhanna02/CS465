const Trip = require('../models/trip');

const getTrips = async (req, res) => {
  try {
    const trips = await Trip.find({}).lean();
    res.status(200).json(trips);
  } catch (err) {
    console.error('Unable to retrieve trips:', err.message);
    res.status(500).json({ error: 'Unable to retrieve trips' });
  }
};

module.exports = { getTrips };
