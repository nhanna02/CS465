const fs = require('fs');
const path = require('path');
const db = require('../app_server/models/db');
const Trip = require('../app_server/models/trip');

async function seed() {
  try {
    await db.connect();
    const file = path.join(__dirname, 'trips.json');
    const trips = JSON.parse(fs.readFileSync(file, 'utf8'));

    await Trip.deleteMany({});
    await Trip.insertMany(trips);
    console.log(`Inserted ${trips.length} trips into the trips collection.`);
  } catch (err) {
    console.error('Database seed failed:', err.message);
    process.exitCode = 1;
  } finally {
    await db.close();
  }
}

seed();
