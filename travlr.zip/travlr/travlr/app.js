const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const hbs = require('hbs');

const indexRouter = require('./app_server/routes/index');
const travelerRouter = require('./app_server/routes/traveler');
const apiRouter = require('./app_api/routes/index');
const usersRouter = require('./app_api/routes/users');
const db = require('./app_api/models/db');

const app = express();

// Establish the database connection when the server starts.
db.connect().catch(() => {
  console.error('The server started without a MongoDB connection.');
});

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Enable CORS for the Angular admin application.
app.use('/api', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, PUT, DELETE'
  );
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use('/', indexRouter);
app.use('/travel', travelerRouter);
app.use('/api/users', usersRouter);
app.use('/api', apiRouter);

app.use(function(req, res, next) {
  next(createError(404));
});

app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error', { title: 'Travlr Getaways' });
});

module.exports = app;