const express = require('express');
const crypto = require('crypto');
const User = require('../models/user');
const { createToken } = require('../middleware/auth');

const router = express.Router();
const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
};
const passwordMatches = (password, stored) => {
  const [salt, savedHash] = (stored || '').split(':');
  if (!salt || !savedHash) return false;
  const candidate = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(savedHash, 'hex');
  return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
};

// POST /api/users/register creates a user for development/testing.
router.post('/register', async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!name || !email || password.length < 8) {
      return res.status(400).json({ message: 'Name, email, and a password of at least 8 characters are required.' });
    }
    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ message: 'An account with this email already exists.' });
    const user = await User.create({ name, email, passwordHash: hashPassword(password) });
    return res.status(201).json({ message: 'User created.', user: { id: user._id, name: user.name, email: user.email } });
  } catch (err) {
    return res.status(500).json({ message: 'Unable to register user.' });
  }
});

// POST /api/users/login
router.post('/login', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const user = await User.findOne({ email });
    if (!user || !passwordMatches(password, user.passwordHash)) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }
    return res.status(200).json({
      token: createToken(user),
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (err) {
    return res.status(500).json({ message: 'Unable to log in.' });
  }
});

module.exports = router;
