const crypto = require('crypto');

const getSecret = () => process.env.JWT_SECRET || 'travlr-development-secret-change-before-deployment';

function createToken(user) {
  const encode = value => Buffer.from(JSON.stringify(value)).toString('base64url');
  const header = encode({ alg: 'HS256', typ: 'JWT' });
  const payload = encode({ sub: String(user._id), email: user.email, exp: Math.floor(Date.now() / 1000) + 60 * 60 });
  const signature = crypto.createHmac('sha256', getSecret()).update(`${header}.${payload}`).digest('base64url');
  return `${header}.${payload}.${signature}`;
}

function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const match = header.match(/^Bearer (.+)$/i);
  if (!match) return res.status(401).json({ message: 'Authentication required. Provide a Bearer token.' });
  const token = match[1];
  const parts = token.split('.');
  if (parts.length !== 3) return res.status(401).json({ message: 'Invalid token.' });
  const expected = crypto.createHmac('sha256', getSecret()).update(`${parts[0]}.${parts[1]}`).digest();
  let actual;
  try { actual = Buffer.from(parts[2], 'base64url'); } catch (_) { return res.status(401).json({ message: 'Invalid token.' }); }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) {
    return res.status(401).json({ message: 'Invalid token.' });
  }
  try {
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp <= Math.floor(Date.now() / 1000)) return res.status(401).json({ message: 'Token expired.' });
    req.user = payload;
    return next();
  } catch (_) { return res.status(401).json({ message: 'Invalid token.' }); }
}

module.exports = { authenticate, createToken };
