const Trip = require('../models/trip');

// GET: /api/trips - Return all trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).lean();

    if (!trips || trips.length === 0) {
      return res.status(404).json({ message: 'No trips found' });
    }

    return res.status(200).json(trips);
  } catch (err) {
    console.error('Unable to retrieve trips:', err.message);
    return res.status(500).json({ message: 'Unable to retrieve trips' });
  }
};

// GET: /api/trips/:tripCode - Return one trip
const tripsFindByCode = async (req, res) => {
  try {
    const trips = await Trip.find({ code: req.params.tripCode }).lean();

    if (!trips || trips.length === 0) {
      return res.status(404).json({
        message: `Trip not found with code ${req.params.tripCode}`
      });
    }

    return res.status(200).json(trips[0]);
  } catch (err) {
    console.error('Unable to retrieve trip:', err.message);
    return res.status(500).json({ message: 'Unable to retrieve trip' });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode
};
