const express = require('express');
const router = express.Router();
const Trip = require('../models/trip');

// GET: /api/trips
// Return all trips
router.get('/trips', async (req, res) => {
  try {
    const trips = await Trip.find({}).lean();

    return res.status(200).json(trips);
  } catch (err) {
    console.error('Unable to retrieve trips:', err.message);
    return res.status(500).json({
      message: 'Unable to retrieve trips'
    });
  }
});

// GET: /api/trips/:tripCode
// Return one trip
router.get('/trips/:tripCode', async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.params.tripCode
    }).lean();

    if (!trip) {
      return res.status(404).json({
        message: `Trip not found with code ${req.params.tripCode}`
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error('Unable to retrieve trip:', err.message);
    return res.status(500).json({
      message: 'Unable to retrieve trip'
    });
  }
});

// POST: /api/trips
// Add a new trip
router.post('/trips', async (req, res) => {
  try {
    const trip = new Trip(req.body);
    const savedTrip = await trip.save();

    return res.status(201).json(savedTrip);
  } catch (err) {
    console.error('Unable to add trip:', err.message);
    return res.status(400).json({
      message: err.message
    });
  }
});

// PUT: /api/trips/:tripCode
// Update an existing trip
router.put('/trips/:tripCode', async (req, res) => {
  try {
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: req.params.tripCode },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
      },
      {
        new: true,
        runValidators: true
      }
    );

    if (!updatedTrip) {
      return res.status(404).json({
        message: `Trip not found with code ${req.params.tripCode}`
      });
    }

    return res.status(200).json(updatedTrip);
  } catch (err) {
    console.error('Unable to update trip:', err.message);
    return res.status(400).json({
      message: err.message
    });
  }
});

// DELETE: /api/trips/:tripCode
// Delete a trip
router.delete('/trips/:tripCode', async (req, res) => {
  try {
    const deletedTrip = await Trip.findOneAndDelete({
      code: req.params.tripCode
    });

    if (!deletedTrip) {
      return res.status(404).json({
        message: `Trip not found with code ${req.params.tripCode}`
      });
    }

    return res.status(204).send();
  } catch (err) {
    console.error('Unable to delete trip:', err.message);
    return res.status(500).json({
      message: 'Unable to delete trip'
    });
  }
});

module.exports = router;