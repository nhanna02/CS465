import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Router } from '@angular/router';

export interface LoginResponse {
  token: string;
  user: { id: string; name: string; email: string };
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  private apiUrl = 'http://localhost:3000/api/users';

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, { email, password }).pipe(
      tap(response => {
        localStorage.setItem('travlr_token', response.token);
        localStorage.setItem('travlr_user', JSON.stringify(response.user));
      })
    );
  }

  get token(): string | null { return localStorage.getItem('travlr_token'); }
  get isLoggedIn(): boolean { return !!this.token; }

  logout(): void {
    localStorage.removeItem('travlr_token');
    localStorage.removeItem('travlr_user');
    this.router.navigate(['/login']);
  }
}
