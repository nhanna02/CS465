import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TripService } from './trip.service';
import { Trip } from './trip';
import { TripCardComponent } from './trip-card.component';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, RouterLink, TripCardComponent],
  templateUrl: './trip-list.component.html'
})
export class TripListComponent implements OnInit {
  private tripService = inject(TripService);
  trips: Trip[] = [];
  loading = true;
  error = '';

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.loading = true;
    this.tripService.getTrips().subscribe({
      next: trips => {
        this.trips = trips;
        this.loading = false;
      },
      error: err => {
        console.error(err);
        this.error = 'Unable to load trips. Make sure the Express API is running.';
        this.loading = false;
      }
    });
  }

  deleteTrip(code: string): void {
    if (!confirm('Delete this trip?')) return;
    this.tripService.deleteTrip(code).subscribe({
      next: () => this.loadTrips(),
      error: err => {
        console.error(err);
        this.error = 'Unable to delete the trip.';
      }
    });
  }
}