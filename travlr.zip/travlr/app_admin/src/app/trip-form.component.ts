import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { TripService } from './trip.service';
import { Trip } from './trip';

@Component({
  selector: 'app-trip-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './trip-form.component.html'
})
export class TripFormComponent implements OnInit {

  private fb = inject(FormBuilder);
  private tripService = inject(TripService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  isEdit = false;
  originalCode = '';
  error = '';
  saving = false;

  form = this.fb.nonNullable.group({
    code: ['', Validators.required],
    name: ['', Validators.required],
    length: ['', Validators.required],
    start: ['', Validators.required],
    resort: ['', Validators.required],
    perPerson: ['', Validators.required],
    image: ['', Validators.required],
    description: ['', Validators.required]
  });

  ngOnInit(): void {
    const code = this.route.snapshot.paramMap.get('code');

    if (code) {
      this.isEdit = true;
      this.originalCode = code;

      this.tripService.getTrip(code).subscribe({
        next: trip => {

          let startDate = '';

          if (trip.start) {
            startDate = new Date(trip.start)
              .toISOString()
              .split('T')[0];
          }

          this.form.patchValue({
            code: trip.code,
            name: trip.name,
            length: trip.length,
            start: startDate,
            resort: trip.resort,
            perPerson: trip.perPerson,
            image: trip.image,
            description: trip.description
          });
        },

        error: err => {
          console.error(err);
          this.error = 'Unable to load the selected trip.';
        }
      });
    }
  }

  submit(): void {

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving = true;
    this.error = '';

    const trip = this.form.getRawValue() as Trip;

    const request$ = this.isEdit
      ? this.tripService.updateTrip(this.originalCode, trip)
      : this.tripService.addTrip(trip);

    request$.subscribe({
      next: () => {
        this.router.navigate(['/trips']);
      },

      error: err => {
        console.error(err);

        this.error =
          err?.error?.message ||
          'Unable to save the trip.';

        this.saving = false;
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/trips']);
  }
}