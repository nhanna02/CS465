import { Routes } from '@angular/router';
import { TripListComponent } from './trip-list.component';
import { TripFormComponent } from './trip-form.component';
import { LoginComponent } from './login.component';
import { authGuard } from './auth.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: '', pathMatch: 'full', redirectTo: 'trips' },
  { path: 'trips', component: TripListComponent, canActivate: [authGuard] },
  { path: 'trips/new', component: TripFormComponent, canActivate: [authGuard] },
  { path: 'trips/edit/:code', component: TripFormComponent, canActivate: [authGuard] },
  { path: '**', redirectTo: 'trips' }
];
