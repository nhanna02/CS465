import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm">
          <div class="card-body p-4">
            <h1 class="h3 mb-3">Administrator Login</h1>
            <p class="text-muted">Sign in to manage Travlr Getaways trips.</p>
            <div *ngIf="error" class="alert alert-danger" role="alert">{{ error }}</div>
            <form (ngSubmit)="submit()" #loginForm="ngForm">
              <div class="mb-3">
                <label class="form-label" for="email">Email</label>
                <input class="form-control" id="email" name="email" type="email" required
                  [(ngModel)]="email" autocomplete="username">
              </div>
              <div class="mb-3">
                <label class="form-label" for="password">Password</label>
                <input class="form-control" id="password" name="password" type="password" required
                  [(ngModel)]="password" autocomplete="current-password">
              </div>
              <button class="btn btn-primary w-100" type="submit" [disabled]="loading || !loginForm.valid">
                {{ loading ? 'Signing in...' : 'Log In' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  email = '';
  password = '';
  error = '';
  loading = false;

  submit(): void {
    this.error = '';
    this.loading = true;
    this.auth.login(this.email, this.password).subscribe({
      next: () => this.router.navigate(['/trips']),
      error: err => {
        this.error = err?.error?.message || 'Login failed. Check the API and your credentials.';
        this.loading = false;
      }
    });
  }
}
