const express = require('express');
const router = express.Router();
const Trip = require('../../travlr/app_api/models/trip');

router.get('/', async (req, res) => {
  try {
    const trips = await Trip.find();
    res.status(200).json(trips);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/:code', async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.code });
    if (!trip) return res.status(404).json({ message: 'Trip not found' });
    res.status(200).json(trip);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const trip = new Trip(req.body);
    const saved = await trip.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.put('/:code', async (req, res) => {
  try {
    const updated = await Trip.findOneAndUpdate(
      { code: req.params.code },
      req.body,
      { new: true, runValidators: true }
    );
    if (!updated) return res.status(404).json({ message: 'Trip not found' });
    res.status(200).json(updated);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.delete('/:code', async (req, res) => {
  try {
    const deleted = await Trip.findOneAndDelete({ code: req.params.code });
    if (!deleted) return res.status(404).json({ message: 'Trip not found' });
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
