const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve all static Travlr Getaways files from the public folder.
app.use(express.static(path.join(__dirname, 'public')));

// Send index.html for the root URL.
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Travlr Getaways is running at http://localhost:${PORT}`);
});
